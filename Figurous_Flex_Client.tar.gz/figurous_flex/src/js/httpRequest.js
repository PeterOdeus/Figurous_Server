Requester = function() {}

Requester.prototype.onreadystatechange = function() {
	if(this.xmlHttpRequest.readyState == 4){
		if(this.xmlHttpRequest.status == 200){
			displayResponse("200: " + this.xmlHttpRequest.responseText, this.displayElementIdPrefix);
			this.responder(this.xmlHttpRequest);
		}else {
			displayResponse("!200: " + this.xmlHttpRequest.responseText, this.displayElementIdPrefix);
			this.responder("damn!!! Http response:" + this.xmlHttpRequest.status);
		}
	}
}

function displayRequest(method, url, body, headers, displayElementIdPrefix) {
  var requestDiv = document.getElementById(displayElementIdPrefix + "_request");
  requestDiv.innerHTML =
  "<pre>" +
  method + " " + url + "\n" +
  headerStringsFromHeaders(headers).join("\n") + "\n" +
  "\n" +
  (body == null ? "" : htmlEscape(body)) +
  "</pre>";
}

function displayResponse(response, displayElementIdPrefix) {
  var requestDiv = document.getElementById(displayElementIdPrefix + "_response");
  requestDiv.innerHTML =
  "<pre>responseXML: " +  response +  "END</pre>";
}

Requester.prototype.request = function(method, url, body, responder,
                                       displayElementIdPrefix) {
  this.displayElementIdPrefix = displayElementIdPrefix;                                       
  var headers = constructRequestHeaders(null);
  displayRequest(method, url, body, headers, displayElementIdPrefix);
  this.responder = responder;
  if (isXMLHttpRequestDefined()) {
    this.xmlHttpRequest = newXMLHttpRequest();
  } else if (isActiveXObjectDefined()) {
    this.xmlHttpRequest = newActiveXObject("Microsoft.XMLHTTP");
  }
  var self = this;
  this.xmlHttpRequest.onreadystatechange = function() {
    self.onreadystatechange();
  };
  this.xmlHttpRequest.open(method, url, /*async*/true);
  /*for (var headerName in headers) {
    this.xmlHttpRequest.setRequestHeader(headerName, headers[headerName]);
  }*/
  this.xmlHttpRequest.setRequestHeader("Accept", "*/*");
  this.xmlHttpRequest.send(body);
}

function isActiveXObjectDefined() {
  return typeof ActiveXObject != "undefined";
}

function isXMLHttpRequestDefined() {
  return typeof XMLHttpRequest != "undefined";
}

function newActiveXObject(progId) {
  return new ActiveXObject(progId);
}

function newXMLHttpRequest() {
  return new XMLHttpRequest();
}

function constructRequestHeaders(token) {
  var headers = new Array();
  //headers["Content-Type"] = "application/atom+xml";
  //headers["Authorization"] = 'AuthSub token="' + token + '"';
  //headers["X-Google-Key"] = '';
  return headers;
}

function headerStringsFromHeaders(headers) {
  var headerStrings = new Array();
  for (var headerName in headers) {
    headerStrings.push(headerName + ": " + headers[headerName]);
  }
  return headerStrings;
}
